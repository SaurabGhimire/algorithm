package lab7_3.universal_hashing2;

abstract public class HashFunction {
	
	
	public HashFunction(){
		
	}
	abstract public int hash(Object ob);
}
